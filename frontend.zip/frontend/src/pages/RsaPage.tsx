export default function RsaPage() {
  return (
    <div className="content">
      <div className="card">
        <h2>1. Криптосистема RSA</h2>
        <p>
          Реализация RSA: генерация ключей, шифрование, расшифрование.
          Алгоритмы атаки на систему.
        </p>
      </div>

      <div className="card">
        <h3>Разделы</h3>
        <ul className="steps">
          <li>Генерация пары ключей (p, q, n, φ(n), e, d)</li>
          <li>Шифрование / расшифрование сообщения</li>
          <li>Атаки: факторизация n, атака Винера, атака на малый e</li>
        </ul>
      </div>

      <div className="placeholder">
        <h2>Интерфейс RSA</h2>
        <p>Формы и вызовы к Go-backend появятся на следующем шаге</p>
      </div>
    </div>
  )
}
