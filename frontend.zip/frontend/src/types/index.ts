/** Общие типы для криптографических операций */

export interface ApiResponse<T> {
  data?: T
  error?: string
}

/** ——— RSA ——— */

export interface RsaKeyPair {
  n: string
  e: string
  d: string
  p?: string
  q?: string
  phi?: string
}

export interface RsaEncryptRequest {
  message: string
  n: string
  e: string
}

export interface RsaEncryptResponse {
  ciphertext: string
}

export interface RsaDecryptRequest {
  ciphertext: string
  n: string
  d: string
}

export interface RsaDecryptResponse {
  plaintext: string
}

export interface RsaAttackRequest {
  n: string
  e: string
  ciphertext?: string
}

export interface RsaAttackResponse {
  method: string
  factors?: { p: string; q: string }
  privateKey?: string
  plaintext?: string
  details?: string
}
